<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CustomerController.php';

// Only run on POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../views/register.php');
}

// Sanitize inputs
$name = trim(strip_tags($_POST['name'] ?? ''));
$email = trim(strip_tags($_POST['email'] ?? ''));
$pass = $_POST['pass'] ?? ''; // Raw password, no hashing here
$country = trim(strip_tags($_POST['country'] ?? ''));
$city = trim(strip_tags($_POST['city'] ?? ''));
$contact = trim(strip_tags($_POST['contact'] ?? ''));

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['error'] = 'Invalid email format.';
    redirect('../views/register.php');
}

// Validate email length (customer_email is VARCHAR 100)
if (strlen($email) > 100) {
    $_SESSION['error'] = 'Email is too long (max 100 characters).';
    redirect('../views/register.php');
}

// Password Validation (AZ, a-z, 0-9, special characters)
$passRegex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{6,}$/';
if (!preg_match($passRegex, $pass)) {
    $_SESSION['error'] = 'Password must be at least 6 characters and contain at least one uppercase letter, one lowercase letter, one number, and one special character.';
    redirect('../views/register.php');
}

// Prepare data array for controller
$data = [
    'name' => $name,
    'email' => $email,
    'pass' => $pass,
    'country' => $country,
    'city' => $city,
    'contact' => $contact
];

// Call Controller -> register() method (NOT insert)
$controller = new CustomerController();
$result = $controller->register($data);

if ($result['success']) {
    // Set session variables using the real ID
    $_SESSION['customer_id'] = $result['customer_id'];
    $_SESSION['customer_name'] = $name;
    $_SESSION['customer_email'] = $email;
    $_SESSION['user_role'] = 2; // Default customer role
    
    redirect('../views/account/my_account.php');
} else {
    $_SESSION['error'] = $result['error'];
    redirect('../views/register.php');
}
?>