<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CustomerController.php';

// Only run on POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(BASE_URL . 'views/login.php');
}

// Sanitize inputs
$email = trim(strip_tags($_POST['email'] ?? ''));
$pass = $_POST['pass'] ?? '';

// Basic validation
if (empty($email) || empty($pass)) {
    $_SESSION['error'] = 'Please fill in both email and password.';
    redirect(BASE_URL . 'views/login.php');
}

// Call Controller
$controller = new CustomerController();
$result = $controller->login($email, $pass);

if ($result['success']) {
    // Store customer details in session
    $_SESSION['customer_id'] = $result['customer']['customer_id'];
    $_SESSION['customer_name'] = $result['customer']['customer_name'];
    $_SESSION['customer_email'] = $result['customer']['customer_email'];
    $_SESSION['user_role'] = $result['customer']['user_role'];
    
    // Redirect to home page on success
    redirect(BASE_URL . 'index.php');
} else {
    // Store error and redirect back to login page
    $_SESSION['error'] = $result['error'];
    redirect(BASE_URL . 'views/login.php');
}
?>