<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

require_admin(); // Stop non-admins

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(BASE_URL . 'views/admin/brand.php');
}

$name = trim(strip_tags($_POST['brand_name'] ?? ''));

if (empty($name)) {
    $_SESSION['error'] = 'Brand name cannot be empty.';
    redirect(BASE_URL . 'views/admin/brand.php');
}

$controller = new ProductController();
if ($controller->addBrand($name)) {
    $_SESSION['success'] = 'Brand added successfully.';
} else {
    $_SESSION['error'] = 'Failed to add brand.';
}

redirect(BASE_URL . 'views/admin/brand.php');
?>