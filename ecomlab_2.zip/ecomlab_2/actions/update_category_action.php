<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(BASE_URL . 'views/admin/category.php');
}

$id = filter_var($_POST['cat_id'] ?? 0, FILTER_VALIDATE_INT);
$name = trim(strip_tags($_POST['cat_name'] ?? ''));

// Validate ID (must be a positive integer) and Name
if (!$id || $id <= 0 || empty($name)) {
    $_SESSION['error'] = 'Invalid category ID or empty name.';
    redirect(BASE_URL . 'views/admin/category.php');
}

$controller = new ProductController();
if ($controller->updateCategory($id, $name)) {
    $_SESSION['success'] = 'Category updated successfully.';
} else {
    $_SESSION['error'] = 'Failed to update category.';
}

redirect(BASE_URL . 'views/admin/category.php');
?>