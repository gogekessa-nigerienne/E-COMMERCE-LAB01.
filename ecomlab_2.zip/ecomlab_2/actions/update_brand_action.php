<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(BASE_URL . 'views/admin/brand.php');
}

$id = filter_var($_POST['brand_id'] ?? 0, FILTER_VALIDATE_INT);
$name = trim(strip_tags($_POST['brand_name'] ?? ''));

// Validate ID (must be a positive integer) and Name
if (!$id || $id <= 0 || empty($name)) {
    $_SESSION['error'] = 'Invalid brand ID or empty name.';
    redirect(BASE_URL . 'views/admin/brand.php');
}

$controller = new ProductController();
if ($controller->updateBrand($id, $name)) {
    $_SESSION['success'] = 'Brand updated successfully.';
} else {
    $_SESSION['error'] = 'Failed to update brand.';
}

redirect(BASE_URL . 'views/admin/brand.php');
?>