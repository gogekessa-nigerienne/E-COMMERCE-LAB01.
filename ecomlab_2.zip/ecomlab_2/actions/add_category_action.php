<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(BASE_URL . 'views/admin/category.php');
}

$name = trim(strip_tags($_POST['cat_name'] ?? ''));

if (empty($name)) {
    $_SESSION['error'] = 'Category name cannot be empty.';
    redirect(BASE_URL . 'views/admin/category.php');
}

$controller = new ProductController();
if ($controller->addCategory($name)) {
    $_SESSION['success'] = 'Category added successfully.';
} else {
    $_SESSION['error'] = 'Failed to add category.';
}

redirect(BASE_URL . 'views/admin/category.php');
?>