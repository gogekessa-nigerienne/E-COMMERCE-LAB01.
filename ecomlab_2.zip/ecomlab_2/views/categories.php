<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

$controller = new ProductController();
$categories = $controller->getAllCategories();

require_once __DIR__ . '/layout/header.php';
?>

<h2>Browse Categories</h2>
<p>Select a category to see our products.</p>

<div class="card-grid">
    <?php if (count($categories) > 0): ?>
        <?php foreach ($categories as $cat): ?>
            <div class="card">
                <h3><?php echo htmlspecialchars($cat['cat_name']); ?></h3>
                <a href="#">View Products</a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No categories available yet.</p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>