        </main> <!-- Close .content -->
    </div> <!-- Close .wrapper -->
    
    <footer>
        <p>&copy; <?php echo date('Y'); ?> ecomlab_2. </p>
    </footer>
</body>
</html>