<?php
require_once __DIR__ . '/../../core/core.php';
require_once __DIR__ . '/../layout/header.php';
?>

<h2>My Account</h2>
<p>Welcome, <?php echo htmlspecialchars($_SESSION['customer_name']); ?>!</p>
<p>This is your account dashboard.</p>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>