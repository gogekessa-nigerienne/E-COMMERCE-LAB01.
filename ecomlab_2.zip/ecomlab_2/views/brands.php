<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

$controller = new ProductController();
$brands = $controller->getAllBrands();

require_once __DIR__ . '/layout/header.php';
?>

<h2>Browse Brands</h2>
<p>Select a brand to see our products.</p>

<div class="card-grid">
    <?php if (count($brands) > 0): ?>
        <?php foreach ($brands as $brand): ?>
            <div class="card">
                <h3><?php echo htmlspecialchars($brand['brand_name']); ?></h3>
                <a href="#">View Products</a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No brands available yet.</p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>