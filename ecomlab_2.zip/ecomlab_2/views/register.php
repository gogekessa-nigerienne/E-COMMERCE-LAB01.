<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/layout/header.php';
?>

<h2>Create an Account</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;">
        <?php 
            echo htmlspecialchars($_SESSION['error']); 
            unset($_SESSION['error']); 
        ?>
    </div>
<?php endif; ?>

<form id="registerForm" action="<?php echo BASE_URL; ?>actions/register_action.php" method="POST">
    <div>
        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" required>
        <span class="error" id="nameError"></span>
    </div>
    
    <div>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <span class="error" id="emailError"></span>
    </div>
    
    <div>
        <label for="pass">Password:</label>
        <input type="password" id="pass" name="pass" required>
        <span class="error" id="passError"></span>
    </div>
    
    <div>
        <label for="country">Country:</label>
        <select id="country" name="country" required>
            <option value="">Select Country</option>
            <option value="Ghana">Ghana</option>
            <option value="Nigeria">Nigeria</option>
            <option value="USA">USA</option>
            <option value="UK">UK</option>
        </select>
        <span class="error" id="countryError"></span>
    </div>
    
    <div>
        <label for="city">City:</label>
        <input type="text" id="city" name="city" required>
        <span class="error" id="cityError"></span>
    </div>
    
    <div>
        <label for="contact">Contact Number:</label>
        <input type="text" id="contact" name="contact" required>
        <span class="error" id="contactError"></span>
    </div>

    <div>
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required>
        <span class="error" id="addressError"></span>
    </div>
    
    <button type="submit" id="submitBtn">Register</button>
</form>

<script src="<?php echo BASE_URL; ?>js/validate.js"></script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>