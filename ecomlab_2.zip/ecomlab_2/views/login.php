<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/layout/header.php';
?>

<h2>Customer Login</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;">
        <?php 
            echo htmlspecialchars($_SESSION['error']); 
            unset($_SESSION['error']); 
        ?>
    </div>
<?php endif; ?>

<form id="loginForm" action="<?php echo BASE_URL; ?>actions/login_action.php" method="POST">
    <div>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
    </div>
    
    <div>
        <label for="pass">Password:</label>
        <input type="password" id="pass" name="pass" required>
    </div>
    
    <button type="submit" id="submitBtn">Login</button>
</form>

<p>Don't have an account? <a href="<?php echo BASE_URL; ?>views/register.php">Register here</a></p>

<?php require_once __DIR__ . '/layout/footer.php'; ?>