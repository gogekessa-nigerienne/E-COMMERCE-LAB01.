<?php
require_once __DIR__ . '/../../core/core.php';
require_once __DIR__ . '/../../controllers/ProductController.php';

// Only admins can see this page
require_admin();

$controller = new ProductController();
$editCategory = null;

// Check if we are in "Edit" mode
if (isset($_GET['edit_id'])) {
    $editCategory = $controller->getCategoryById($_GET['edit_id']);
}

require_once __DIR__ . '/../layout/header.php';
?>

<h2><?php echo $editCategory ? 'Edit Category' : 'Manage Categories'; ?></h2>

<!-- Display Success/Error Messages -->
<?php if (isset($_SESSION['success'])): ?>
    <div style="color: green; margin-bottom: 15px;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<!-- Add or Edit Form -->
<form action="<?php echo BASE_URL; ?>actions/<?php echo $editCategory ? 'update_category_action.php' : 'add_category_action.php'; ?>" method="POST">
    <?php if ($editCategory): ?>
        <!-- Hidden field for the ID when editing -->
        <input type="hidden" name="cat_id" value="<?php echo $editCategory['cat_id']; ?>">
    <?php endif; ?>
    
    <div>
        <label for="cat_name">Category Name:</label>
        <input type="text" id="cat_name" name="cat_name" required 
               value="<?php echo $editCategory ? htmlspecialchars($editCategory['cat_name']) : ''; ?>">
    </div>
    
    <button type="submit"><?php echo $editCategory ? 'Update Category' : 'Add Category'; ?></button>
    
    <?php if ($editCategory): ?>
        <a href="<?php echo BASE_URL; ?>views/admin/category.php" style="margin-left: 10px;">Cancel Edit</a>
    <?php endif; ?>
</form>

<hr>

<!-- Categories Table -->
<h3>All Categories</h3>
<table border="1" cellpadding="10" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Category Name</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $categories = $controller->getAllCategories();
        if (count($categories) > 0):
            foreach ($categories as $cat): 
        ?>
            <tr>
                <td><?php echo $cat['cat_id']; ?></td>
                <td><?php echo htmlspecialchars($cat['cat_name']); ?></td>
                <td>
                    <a href="<?php echo BASE_URL; ?>views/admin/category.php?edit_id=<?php echo $cat['cat_id']; ?>">Edit</a>
                </td>
            </tr>
        <?php 
            endforeach; 
        else:
        ?>
            <tr><td colspan="3">No categories found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>