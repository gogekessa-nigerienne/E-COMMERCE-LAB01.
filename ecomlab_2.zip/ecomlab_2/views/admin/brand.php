<?php
require_once __DIR__ . '/../../core/core.php';
require_once __DIR__ . '/../../controllers/ProductController.php';

// Only admins can see this page
require_admin();

$controller = new ProductController();
$editBrand = null;

// Check if we are in "Edit" mode
if (isset($_GET['edit_id'])) {
    $editBrand = $controller->getBrandById($_GET['edit_id']);
}

require_once __DIR__ . '/../layout/header.php';
?>

<h2><?php echo $editBrand ? 'Edit Brand' : 'Manage Brands'; ?></h2>

<!-- Display Success/Error Messages -->
<?php if (isset($_SESSION['success'])): ?>
    <div style="color: green; margin-bottom: 15px;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<!-- Add or Edit Form -->
<form action="<?php echo BASE_URL; ?>actions/<?php echo $editBrand ? 'update_brand_action.php' : 'add_brand_action.php'; ?>" method="POST">
    <?php if ($editBrand): ?>
        <input type="hidden" name="brand_id" value="<?php echo $editBrand['brand_id']; ?>">
    <?php endif; ?>
    
    <div>
        <label for="brand_name">Brand Name:</label>
        <input type="text" id="brand_name" name="brand_name" required 
               value="<?php echo $editBrand ? htmlspecialchars($editBrand['brand_name']) : ''; ?>">
    </div>
    
    <button type="submit"><?php echo $editBrand ? 'Update Brand' : 'Add Brand'; ?></button>
    
    <?php if ($editBrand): ?>
        <a href="<?php echo BASE_URL; ?>views/admin/brand.php" style="margin-left: 10px;">Cancel Edit</a>
    <?php endif; ?>
</form>

<hr>

<!-- Brands Table -->
<h3>All Brands</h3>
<table border="1" cellpadding="10" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Brand Name</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $brands = $controller->getAllBrands();
        if (count($brands) > 0):
            foreach ($brands as $brand): 
        ?>
            <tr>
                <td><?php echo $brand['brand_id']; ?></td>
                <td><?php echo htmlspecialchars($brand['brand_name']); ?></td>
                <td>
                    <a href="<?php echo BASE_URL; ?>views/admin/brand.php?edit_id=<?php echo $brand['brand_id']; ?>">Edit</a>
                </td>
            </tr>
        <?php 
            endforeach; 
        else:
        ?>
            <tr><td colspan="3">No brands found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>