<?php
require_once __DIR__ . '/../core/db_class.php';

class CustomerClass extends Database {

    // Check if email already exists
    public function emailExists($email) {
        $sql = "SELECT customer_email FROM customer WHERE customer_email = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows > 0;
    }

    // Add a new customer and return their new ID
    public function addCustomer($name, $email, $pass, $country, $city, $contact) {
        // Hash the password securely
        $hashed_pass = password_hash($pass, PASSWORD_BCRYPT);
        
        $sql = "INSERT INTO customer (customer_name, customer_email, customer_pass, customer_country, customer_city, customer_contact) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        // "ssssss" means 6 string parameters
        $stmt->bind_param("ssssss", $name, $email, $hashed_pass, $country, $city, $contact);
        
        if ($stmt->execute()) {
            // Return the newly created ID
            return $this->conn->insert_id;
        }
        return false;
    }

        // Fetch a single customer row by email
    public function getCustomerByEmail($email) {
        $sql = "SELECT * FROM customer WHERE customer_email = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return $result->fetch_assoc(); // Returns the row as an array
        }
        return false;
    }

    // Verify password and return customer row on success
    public function login($email, $pass) {
        $row = $this->getCustomerByEmail($email);
        
        // If email exists AND password matches the hash
        if ($row && password_verify($pass, $row['customer_pass'])) {
            return $row;
        }
        return false;
    }
}
?>