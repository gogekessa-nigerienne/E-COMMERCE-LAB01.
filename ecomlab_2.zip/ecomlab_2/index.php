<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'core/core.php';
require_once 'views/layout/header.php';
?>

<h1>Welcome to our Store</h1>
<p>This is the home page. Browse our products soon!</p>

<?php
require_once 'views/layout/footer.php';
?>