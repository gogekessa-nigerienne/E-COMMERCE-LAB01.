<?php
require_once __DIR__ . '/../classes/CustomerClass.php';

class CustomerController {
    private $customerModel;

    public function __construct() {
        $this->customerModel = new CustomerClass();
    }

    public function register($data) {
        $name = $data['name'];
        $email = $data['email'];
        $pass = $data['pass'];
        $country = $data['country'];
        $city = $data['city'];
        $contact = $data['contact'];

        if ($this->customerModel->emailExists($email)) {
            return ['success' => false, 'error' => 'Email already registered'];
        }

        $new_id = $this->customerModel->addCustomer($name, $email, $pass, $country, $city, $contact);
        
        if ($new_id) {
            return ['success' => true, 'customer_id' => $new_id];
        } else {
            return ['success' => false, 'error' => 'Registration failed. Please try again.'];
        }
    }


        public function login($email, $pass) {
        $customer = $this->customerModel->login($email, $pass);
        
        if ($customer) {
            return ['success' => true, 'customer' => $customer];
        } else {
            return ['success' => false, 'error' => 'Invalid email or password.'];
        }
    }
}
?>