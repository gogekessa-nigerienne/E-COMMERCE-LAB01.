document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registerForm');
    const submitBtn = document.getElementById('submitBtn');

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9+\-\s]{7,15}$/;
    // Regex for password: At least one uppercase, one lowercase, one digit, one special character, min 6 chars
    const passRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{6,}$/;

    form.addEventListener('submit', function(event) {
        let isValid = true;

        // Clear previous errors
        document.querySelectorAll('.error').forEach(el => el.textContent = '');

        // Validate Email
        const email = document.getElementById('email').value;
        if (!emailRegex.test(email)) {
            document.getElementById('emailError').textContent = 'Invalid email format.';
            isValid = false;
        }

        // Validate Phone
        const contact = document.getElementById('contact').value;
        if (!phoneRegex.test(contact)) {
            document.getElementById('contactError').textContent = 'Invalid phone number (7-15 digits, +, -, spaces).';
            isValid = false;
        }

        // Validate Password
        const pass = document.getElementById('pass').value;
        if (!passRegex.test(pass)) {
            document.getElementById('passError').textContent = 'Password must be at least 6 characters and include uppercase, lowercase, number, and special character.';
            isValid = false;
        }

        // Prevent submission if invalid
        if (!isValid) {
            event.preventDefault();
            return;
        }

        // Show loading state
        submitBtn.textContent = 'Registering...';
        submitBtn.disabled = true;
    });
});