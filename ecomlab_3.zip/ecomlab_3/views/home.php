<hr style="margin: 40px 0;">

<h2>Shop by Category</h2>
<table border="1" cellpadding="10" cellspacing="0" style="width: 100%; border-collapse: collapse; margin-top: 15px; background: white;">
    <thead style="background: #2c3e50; color: white;">
        <tr>
            <th style="text-align: left; width: 80px;">Image</th>
            <th style="text-align: left;">Category Name</th>
            <th style="text-align: left; width: 150px;">Browse</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $homeCategories = $controller->getAllCategories();
        foreach ($homeCategories as $cat): 
        ?>
            <tr>
                <td><img src="<?php echo BASE_URL . 'images/categories/' . $cat['cat_image']; ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;"></td>
                <td style="font-size: 16px;"><?php echo htmlspecialchars($cat['cat_name']); ?></td>
                <td><a href="<?php echo BASE_URL; ?>index.php?cat=<?php echo $cat['cat_id']; ?>" style="padding: 6px 12px; background: #2c3e50; color: white; text-decoration: none; border-radius: 4px;">View Products</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<hr style="margin: 40px 0;">

<h2>Shop by Brand</h2>
<table border="1" cellpadding="10" cellspacing="0" style="width: 100%; border-collapse: collapse; margin-top: 15px; background: white;">
    <thead style="background: #2c3e50; color: white;">
        <tr>
            <th style="text-align: left; width: 80px;">Image</th>
            <th style="text-align: left;">Brand Name</th>
            <th style="text-align: left; width: 150px;">Browse</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $homeBrands = $controller->getAllBrands();
        foreach ($homeBrands as $brand): 
        ?>
            <tr>
                <td><img src="<?php echo BASE_URL . 'images/brands/' . $brand['brand_image']; ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;"></td>
                <td style="font-size: 16px;"><?php echo htmlspecialchars($brand['brand_name']); ?></td>
                <td><a href="<?php echo BASE_URL; ?>index.php?brand=<?php echo $brand['brand_id']; ?>" style="padding: 6px 12px; background: #2c3e50; color: white; text-decoration: none; border-radius: 4px;">View Products</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>