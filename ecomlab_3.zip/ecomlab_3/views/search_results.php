<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

$controller = new ProductController();
$query = $_GET['user_query'] ?? '';
$products = $controller->searchProducts($query);

require_once __DIR__ . '/layout/header.php';
?>

<h2>Search Results for "<?php echo htmlspecialchars($query); ?>"</h2>

<div class="card-grid">
    <?php if (count($products) > 0): ?>
        <?php foreach ($products as $prod): ?>
            <div class="card">
                <img src="<?php echo BASE_URL . 'images/products/' . $prod['product_image']; ?>" alt="<?php echo htmlspecialchars($prod['product_title']); ?>" style="width: 100%; height: 150px; object-fit: cover; border-radius: 4px; margin-bottom: 10px;">
                <h3><?php echo htmlspecialchars($prod['product_title']); ?></h3>
                <p><strong>$<?php echo $prod['product_price']; ?></strong></p>
                <a href="<?php echo BASE_URL; ?>views/single_product.php?pro_id=<?php echo $prod['product_id']; ?>">View Details</a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No products found matching your search.</p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>