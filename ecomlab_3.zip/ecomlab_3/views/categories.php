<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

$controller = new ProductController();
$categories = $controller->getAllCategories();

require_once __DIR__ . '/layout/header.php';
?>

<h2>Browse Categories</h2>
<p>Select a category to see our products.</p>

<table border="1" cellpadding="15" cellspacing="0" style="width: 100%; border-collapse: collapse; margin-top: 20px; background: white;">
    <thead style="background: #2c3e50; color: white;">
        <tr>
            <th style="text-align: left; width: 80px;">Image</th>
            <th style="text-align: left;">Category Name</th>
            <th style="text-align: left; width: 150px;">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($categories) > 0): ?>
            <?php foreach ($categories as $cat): ?>
                <tr>
                    <td>
                        <img src="<?php echo BASE_URL . 'images/categories/' . $cat['cat_image']; ?>" 
                             alt="<?php echo htmlspecialchars($cat['cat_name']); ?>" 
                             style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                    </td>
                    <td style="font-size: 16px;"><?php echo htmlspecialchars($cat['cat_name']); ?></td>
                    <td>
                        <a href="<?php echo BASE_URL; ?>index.php?cat=<?php echo $cat['cat_id']; ?>" 
                           style="padding: 6px 12px; background: #2c3e50; color: white; text-decoration: none; border-radius: 4px;">
                           View Products
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="3">No categories available yet.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/layout/footer.php'; ?>