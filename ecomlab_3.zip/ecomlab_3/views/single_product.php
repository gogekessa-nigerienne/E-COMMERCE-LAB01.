<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

if (!isset($_GET['pro_id']) || !is_numeric($_GET['pro_id'])) {
    redirect(BASE_URL . 'index.php');
}

$controller = new ProductController();
$product = $controller->getProductById((int)$_GET['pro_id']);

if (!$product) {
    redirect(BASE_URL . 'index.php');
}

require_once __DIR__ . '/layout/header.php';
?>

<h2><?php echo htmlspecialchars($product['product_title']); ?></h2>

<div style="display: flex; gap: 30px; margin-top: 20px;">
    <div style="flex: 1;">
        <img src="<?php echo BASE_URL . 'images/products/' . $product['product_image']; ?>" alt="<?php echo htmlspecialchars($product['product_title']); ?>" style="width: 100%; max-width: 400px; border-radius: 5px;">
    </div>
    <div style="flex: 2;">
        <p><strong>Price:</strong> $<?php echo $product['product_price']; ?></p>
        <p><strong>Category:</strong> <?php echo htmlspecialchars($product['cat_name']); ?></p>
        <p><strong>Brand:</strong> <?php echo htmlspecialchars($product['brand_name']); ?></p>
        <p><strong>Description:</strong></p>
        <p><?php echo nl2br(htmlspecialchars($product['product_desc'])); ?></p>
        <p><strong>Keywords:</strong> <?php echo htmlspecialchars($product['product_keywords']); ?></p>
        <br>
        <a href="<?php echo BASE_URL; ?>views/cart.php?add=<?php echo $product['product_id']; ?>" style="padding: 10px 20px; background: #2c3e50; color: white; text-decoration: none; border-radius: 5px;">Add to Cart</a>
    </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>