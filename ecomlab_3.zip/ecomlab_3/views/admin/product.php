<?php
require_once __DIR__ . '/../../core/core.php';
require_once __DIR__ . '/../../controllers/ProductController.php';

require_admin();

$controller = new ProductController();
$editProduct = null;

if (isset($_GET['edit_id'])) {
    $editProduct = $controller->getProductById($_GET['edit_id']);
}

$categories = $controller->getAllCategories();
$brands = $controller->getAllBrands();

require_once __DIR__ . '/../layout/header.php';
?>

<h2><?php echo $editProduct ? 'Edit Product' : 'Add Product'; ?></h2>

<?php if (isset($_SESSION['success'])): ?>
    <div style="color: green; margin-bottom: 15px;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<form action="<?php echo BASE_URL; ?>actions/<?php echo $editProduct ? 'update_product_action.php' : 'add_product_action.php'; ?>" method="POST" enctype="multipart/form-data">
    <?php if ($editProduct): ?>
        <input type="hidden" name="product_id" value="<?php echo $editProduct['product_id']; ?>">
        <input type="hidden" name="current_image" value="<?php echo $editProduct['product_image']; ?>">
    <?php endif; ?>
    
    <div>
        <label>Title:</label>
        <input type="text" name="product_title" required value="<?php echo $editProduct ? htmlspecialchars($editProduct['product_title']) : ''; ?>">
    </div>
    <div>
        <label>Price:</label>
        <input type="number" step="0.01" name="product_price" required value="<?php echo $editProduct ? $editProduct['product_price'] : ''; ?>">
    </div>
    <div>
        <label>Category:</label>
        <select name="product_cat" required>
            <option value="">Select Category</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['cat_id']; ?>" <?php echo ($editProduct && $editProduct['product_cat'] == $cat['cat_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($cat['cat_name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label>Brand:</label>
        <select name="product_brand" required>
            <option value="">Select Brand</option>
            <?php foreach ($brands as $brand): ?>
                <option value="<?php echo $brand['brand_id']; ?>" <?php echo ($editProduct && $editProduct['product_brand'] == $brand['brand_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($brand['brand_name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label>Description:</label>
        <textarea name="product_desc"><?php echo $editProduct ? htmlspecialchars($editProduct['product_desc']) : ''; ?></textarea>
    </div>
    <div>
        <label>Keywords (comma separated):</label>
        <input type="text" name="product_keywords" value="<?php echo $editProduct ? htmlspecialchars($editProduct['product_keywords']) : ''; ?>">
    </div>
    <div>
        <label>Image:</label>
        <input type="file" name="product_image" accept="image/*">
        <?php if ($editProduct && $editProduct['product_image'] != 'default.jpg'): ?>
            <p>Current: <img src="<?php echo BASE_URL . 'images/products/' . $editProduct['product_image']; ?>" width="80"></p>
        <?php endif; ?>
    </div>
    
    <button type="submit"><?php echo $editProduct ? 'Update Product' : 'Add Product'; ?></button>
    <?php if ($editProduct): ?>
        <a href="<?php echo BASE_URL; ?>views/admin/product.php" style="margin-left: 10px;">Cancel</a>
    <?php endif; ?>
</form>

<hr>
<h3>All Products</h3>
<table border="1" cellpadding="10" cellspacing="0">
    <thead>
        <tr><th>ID</th><th>Title</th><th>Price</th><th>Category</th><th>Brand</th><th>Action</th></tr>
    </thead>
    <tbody>
        <!-- Note: For brevity, we are only showing products added via the admin panel. 
             A full implementation would fetch all products here. -->
        <?php 
        // Fetch all products for the admin table (simplified)
        $all_products = $controller->getFeaturedProducts(100); // Using limit 100 as a quick fix
        foreach ($all_products as $prod): 
        ?>
            <tr>
                <td><?php echo $prod['product_id']; ?></td>
                <td><?php echo htmlspecialchars($prod['product_title']); ?></td>
                <td>$<?php echo $prod['product_price']; ?></td>
                <td><?php echo htmlspecialchars($prod['cat_name']); ?></td>
                <td><?php echo htmlspecialchars($prod['brand_name']); ?></td>
                <td><a href="<?php echo BASE_URL; ?>views/admin/product.php?edit_id=<?php echo $prod['product_id']; ?>">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>