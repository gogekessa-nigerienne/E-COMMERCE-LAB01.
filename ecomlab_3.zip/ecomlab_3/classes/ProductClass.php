<?php
require_once __DIR__ . '/../core/db_class.php';

class ProductClass extends Database {

    // Task 5: Add a new brand
    public function addBrand($name) {
        $sql = "INSERT INTO brands (brand_name) VALUES (?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $name);
        return $stmt->execute();
    }

    // Task 5: Get all brands for the table
    public function getAllBrands() {
        $sql = "SELECT * FROM brands ORDER BY brand_name ASC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Task 6: Get a single brand by ID (for editing)
    public function getBrandById($id) {
        $sql = "SELECT * FROM brands WHERE brand_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    // Task 6: Update an existing brand
    public function updateBrand($id, $name) {
        $sql = "UPDATE brands SET brand_name = ? WHERE brand_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $name, $id);
        return $stmt->execute();
    }

        // Task 7: Add a new category
    public function addCategory($name) {
        $sql = "INSERT INTO categories (cat_name) VALUES (?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $name);
        return $stmt->execute();
    }

    // Task 7: Get all categories for the table
    public function getAllCategories() {
        $sql = "SELECT * FROM categories ORDER BY cat_name ASC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Task 8: Get a single category by ID (for editing)
    public function getCategoryById($id) {
        $sql = "SELECT * FROM categories WHERE cat_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    // Task 8: Update an existing category
    public function updateCategory($id, $name) {
        $sql = "UPDATE categories SET cat_name = ? WHERE cat_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $name, $id);
        return $stmt->execute();
    }


        // TASK 9: Add Product
    public function addProduct($cat, $brand, $title, $price, $desc, $image, $keywords) {
        $sql = "INSERT INTO products (product_cat, product_brand, product_title, product_price, product_desc, product_image, product_keywords) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iisssss", $cat, $brand, $title, $price, $desc, $image, $keywords);
        return $stmt->execute();
    }

    // TASK 9: Update Product
    public function updateProduct($id, $cat, $brand, $title, $price, $desc, $image, $keywords) {
        $sql = "UPDATE products SET product_cat=?, product_brand=?, product_title=?, product_price=?, product_desc=?, product_image=?, product_keywords=? WHERE product_id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iisssssi", $cat, $brand, $title, $price, $desc, $image, $keywords, $id);
        return $stmt->execute();
    }

    // TASK 9: Get Product By ID (with JOIN)
    public function getProductById($id) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name 
                FROM products p 
                JOIN categories c ON p.product_cat = c.cat_id 
                JOIN brands b ON p.product_brand = b.brand_id 
                WHERE p.product_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // TASK 10: Get Featured Products
    public function getFeaturedProducts($limit = 6) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p 
                JOIN categories c ON p.product_cat = c.cat_id 
                JOIN brands b ON p.product_brand = b.brand_id 
                ORDER BY RAND() LIMIT ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // TASK 10: Filter by Category
    public function getProductsByCategory($cat_id) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p 
                JOIN categories c ON p.product_cat = c.cat_id 
                JOIN brands b ON p.product_brand = b.brand_id 
                WHERE p.product_cat = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $cat_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // TASK 10: Filter by Brand
    public function getProductsByBrand($brand_id) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p 
                JOIN categories c ON p.product_cat = c.cat_id 
                JOIN brands b ON p.product_brand = b.brand_id 
                WHERE p.product_brand = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $brand_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // TASK 10: Search Products
    public function searchProducts($query) {
        $search = "%" . $query . "%";
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p 
                JOIN categories c ON p.product_cat = c.cat_id 
                JOIN brands b ON p.product_brand = b.brand_id 
                WHERE p.product_title LIKE ? OR p.product_keywords LIKE ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $search, $search);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
?>