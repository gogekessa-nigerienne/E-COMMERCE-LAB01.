<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect(BASE_URL . 'views/admin/product.php');
}

$cat = filter_var($_POST['product_cat'] ?? 0, FILTER_VALIDATE_INT);
$brand = filter_var($_POST['product_brand'] ?? 0, FILTER_VALIDATE_INT);
$title = trim(strip_tags($_POST['product_title'] ?? ''));
$price = filter_var($_POST['product_price'] ?? 0, FILTER_VALIDATE_FLOAT);
$desc = trim(strip_tags($_POST['product_desc'] ?? ''));
$keywords = trim(strip_tags($_POST['product_keywords'] ?? ''));
$image = 'default.jpg'; // Default if no image uploaded

// Handle Image Upload
if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (in_array($_FILES['product_image']['type'], $allowed)) {
        $filename = uniqid() . '.' . pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION);
        $upload_dir = __DIR__ . '/../images/products/';
        
        if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }
        
        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $upload_dir . $filename)) {
            $image = $filename;
        }
    }
}

$controller = new ProductController();
if ($controller->addProduct($cat, $brand, $title, $price, $desc, $image, $keywords)) {
    $_SESSION['success'] = 'Product added successfully.';
} else {
    $_SESSION['error'] = 'Failed to add product.';
}
redirect(BASE_URL . 'views/admin/product.php');
?>