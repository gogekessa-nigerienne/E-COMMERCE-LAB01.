<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CartController.php';

require_login();

if (!isset($_GET['ref'])) {
    redirect(BASE_URL . 'views/cart.php');
}

$reference = $_GET['ref'];
$ip = get_ip();
$customer_id = $_SESSION['customer_id'];
$controller = new CartController();
$total = $controller->getCartTotal($ip);

$url = 'https://api.paystack.co/transaction/verify/' . $reference;
$options = [
    'http' => [
        'header' => "Authorization: Bearer sk_test_YOUR_SECRET_KEY\r\n" // REPLACE WITH YOUR KEY
    ]
];
$context = stream_context_create($options);
$response = @file_get_contents($url, false, $context);
$result = json_decode($response, true);

if ($result && $result['status'] === true && $result['data']['status'] === 'success') {
    $order_id = $controller->processPayment($customer_id, $ip, $reference, $total);
    
    if ($order_id) {
        redirect(BASE_URL . 'views/payment_success.php?order_id=' . $order_id);
    } else {
        $_SESSION['error'] = 'Payment verified but database error occurred.';
        redirect(BASE_URL . 'views/payment_failed.php');
    }
} else {
    $_SESSION['error'] = 'Payment verification failed.';
    redirect(BASE_URL . 'views/payment_failed.php');
}
?>