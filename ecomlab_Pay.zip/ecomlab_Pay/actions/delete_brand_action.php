<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

require_admin();

if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if ($id) {
        $controller = new ProductController();
        try {
            if ($controller->deleteBrand($id)) {
                $_SESSION['success'] = 'Brand deleted successfully.';
            }
        } catch (mysqli_sql_exception $e) {
            $_SESSION['error'] = 'Cannot delete this brand because it has products assigned to it.';
        }
    }
}
redirect(BASE_URL . 'views/admin/brand.php');
?>