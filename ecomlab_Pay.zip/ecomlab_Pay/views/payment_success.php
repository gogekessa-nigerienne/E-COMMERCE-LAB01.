<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CartController.php';

require_login();

if (!isset($_GET['order_id'])) {
    redirect(BASE_URL . 'index.php');
}

$order_id = (int)$_GET['order_id'];
$controller = new CartController();
$orderItems = $controller->getOrderById($order_id);

require_once __DIR__ . '/layout/header.php';
?>

<div style="background: #e8f8f5; border: 2px solid #2ecc71; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
    <h2 style="color: #27ae60;">Payment Successful!</h2>
    <p>Thank you for your purchase. Your order has been confirmed.</p>
</div>

<?php if (count($orderItems) > 0): ?>
    <h3>Invoice #<?php echo $orderItems[0]['invoice_no']; ?></h3>
    <p><strong>Date:</strong> <?php echo $orderItems[0]['order_date']; ?></p>
    
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $grandTotal = 0;
            foreach ($orderItems as $item): 
                $subtotal = $item['product_price'] * $item['qty'];
                $grandTotal += $subtotal;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product_title']); ?></td>
                    <td><?php echo $item['qty']; ?></td>
                    <td>GH₵ <?php echo number_format($item['product_price'], 2); ?></td>
                    <td>GH₵ <?php echo number_format($subtotal, 2); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align: right; font-weight: bold;">Grand Total:</td>
                <td style="font-weight: bold;">GH₵ <?php echo number_format($grandTotal, 2); ?></td>
            </tr>
        </tfoot>
    </table>
    
    <br>
    <a href="<?php echo BASE_URL; ?>index.php" class="btn">Continue Shopping</a>
<?php else: ?>
    <p>Order not found.</p>
<?php endif; ?>

<?php require_once __DIR__ . '/layout/footer.php'; ?>