<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CartController.php';

require_login();

$ip = get_ip();
$controller = new CartController();
$items = $controller->getCartItems($ip);
$total = $controller->getCartTotal($ip);

if (count($items) === 0) {
    redirect(BASE_URL . 'views/cart.php');
}

require_once __DIR__ . '/layout/header.php';
?>

<h2>Checkout & Payment</h2>

<table>
    <thead>
        <tr>
            <th>Product</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Subtotal</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['product_title']); ?></td>
                <td><?php echo $item['qty']; ?></td>
                <td>GH₵ <?php echo number_format($item['product_price'], 2); ?></td>
                <td>GH₵ <?php echo number_format($item['product_price'] * $item['qty'], 2); ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3" style="text-align: right; font-weight: bold;">Total:</td>
            <td style="font-weight: bold;">GH₵ <?php echo number_format($total, 2); ?></td>
        </tr>
    </tfoot>
</table>

<br>
<button onclick="payWithPaystack()" class="btn" style="font-size: 18px; padding: 12px 24px;">Pay GH₵ <?php echo number_format($total, 2); ?> with Paystack</button>

<script src="https://js.paystack.co/v1/inline.js"></script>
<script>
    function payWithPaystack() {
        var handler = PaystackPop.setup({
            key: 'sk_test_d4ffb430097cd8bcda7587ef153bec6ae4d77163', //  PUBLIC KEY HERE
            email: '<?php echo htmlspecialchars($_SESSION["customer_email"]); ?>',
            amount: <?php echo $total * 100; ?>, // Paystack uses kobo/pesewas
            currency: 'GHS',
            onSuccess: function(response) {
                window.location = '<?php echo BASE_URL; ?>actions/process_payment_action.php?ref=' + response.reference;
            },
            onCancel: function() {
                alert('Payment cancelled.');
            }
        });
        handler.openIframe();
    }
</script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>