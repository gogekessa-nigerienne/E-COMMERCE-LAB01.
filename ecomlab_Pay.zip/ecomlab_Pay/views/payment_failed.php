<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/layout/header.php';
?>

<div style="background: #fadbd8; border: 2px solid #e74c3c; padding: 20px; border-radius: 8px; text-align: center;">
    <h2 style="color: #c0392b;">Payment Failed</h2>
    <p><?php echo $_SESSION['error'] ?? 'Your payment could not be verified. Please try again.'; unset($_SESSION['error']); ?></p>
    <br>
    <a href="<?php echo BASE_URL; ?>views/cart.php" class="btn">Return to Cart</a>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>