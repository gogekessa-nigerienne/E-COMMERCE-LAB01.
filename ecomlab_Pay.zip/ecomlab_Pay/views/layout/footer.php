    </main>
</div>

<footer>
    <p>&copy; <?php echo date('Y'); ?> ecomWeb. All rights reserved.</p>
</footer>

</body>
</html>