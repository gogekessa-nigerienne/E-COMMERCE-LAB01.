<?php
require_once __DIR__ . '/../core/db_class.php';

class CartClass extends Database {

    // Check if a product is already in the cart for this IP
    public function isInCart($pid, $ip) {
        $sql = "SELECT * FROM cart WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $pid, $ip);
        $stmt->execute();
        return $stmt->get_result()->num_rows > 0;
    }

    // Add product to cart
    public function addToCart($pid, $qty, $ip, $cid = null) {
        $sql = "INSERT INTO cart (p_id, ip_add, c_id, qty) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        // If $cid is null, we need a variable reference for bind_param
        $null = null;
        $cidToBind = ($cid === null) ? $null : $cid;
        $stmt->bind_param("isii", $pid, $ip, $cidToBind, $qty);
        return $stmt->execute();
    }

    // Get all cart items with product details
    public function getCartItems($ip) {
        $sql = "SELECT c.qty, p.* FROM cart c 
                JOIN products p ON c.p_id = p.product_id 
                WHERE c.ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $ip);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // Get total quantity of items in cart
    public function getCartCount($ip) {
        $sql = "SELECT SUM(qty) as count FROM cart WHERE ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $ip);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['count'] ?? 0;
    }

    // Get total price of cart
    public function getCartTotal($ip) {
        $sql = "SELECT SUM(c.qty * p.product_price) as total FROM cart c 
                JOIN products p ON c.p_id = p.product_id 
                WHERE c.ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $ip);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['total'] ?? 0;
    }

    // Remove a product from cart
    public function removeFromCart($pid, $ip) {
        $sql = "DELETE FROM cart WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $pid, $ip);
        return $stmt->execute();
    }

    // Update quantity of a product in cart
    public function updateQty($pid, $qty, $ip) {
        if ($qty < 1) { $qty = 1; }
        $sql = "UPDATE cart SET qty = ? WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iis", $qty, $pid, $ip);
        return $stmt->execute();
    }

    // Get the current quantity of a specific product in cart
    public function getQty($pid, $ip) {
        $sql = "SELECT qty FROM cart WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $pid, $ip);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['qty'] ?? 0;
    }

    // ==========================================
    // TASK 13: NEW PAYMENT METHODS BELOW
    // ==========================================

    // Task 13: Process Payment (DB Transaction)
    public function processPayment($customer_id, $ip, $reference, $amount) {
        $this->conn->begin_transaction();
        
        try {
            // 1. Generate invoice number
            $invoice_no = mt_rand(100000, 999999);
            $order_date = date('Y-m-d');
            $order_status = 'paid';
            
            // 2. Insert into orders
            $sql = "INSERT INTO orders (customer_id, invoice_no, order_date, order_status) VALUES (?, ?, ?, ?)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("isss", $customer_id, $invoice_no, $order_date, $order_status);
            $stmt->execute();
            $order_id = $this->conn->insert_id;
            
            // 3. Copy cart rows into orderdetails
            $sql_details = "INSERT INTO orderdetails (order_id, product_id, qty) SELECT ?, p_id, qty FROM cart WHERE ip_add = ?";
            $stmt_details = $this->conn->prepare($sql_details);
            $stmt_details->bind_param("is", $order_id, $ip);
            $stmt_details->execute();
            
            // 4. Delete from cart
            $sql_delete = "DELETE FROM cart WHERE ip_add = ?";
            $stmt_delete = $this->conn->prepare($sql_delete);
            $stmt_delete->bind_param("s", $ip);
            $stmt_delete->execute();
            
            // Commit Transaction
            $this->conn->commit();
            return $order_id;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }

    // Get Order Details for Invoice
    public function getOrderById($order_id) {
        $sql = "SELECT o.*, od.qty, p.product_title, p.product_price, p.product_image 
                FROM orders o 
                JOIN orderdetails od ON o.order_id = od.order_id 
                JOIN products p ON od.product_id = p.product_id 
                WHERE o.order_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
?>