<?php
require_once __DIR__ . '/../classes/ProductClass.php';

class ProductController {
    private $productModel;

    public function __construct() {
        $this->productModel = new ProductClass();


    }

    // Brands
    public function addBrand($name, $image) { return $this->productModel->addBrand($name, $image); }
    public function getAllBrands() { return $this->productModel->getAllBrands(); }
    public function getBrandById($id) { return $this->productModel->getBrandById($id); }
    public function updateBrand($id, $name, $image) { return $this->productModel->updateBrand($id, $name, $image); }

    // Categories
    public function addCategory($name, $image) { return $this->productModel->addCategory($name, $image); }
    public function getAllCategories() { return $this->productModel->getAllCategories(); }
    public function getCategoryById($id) { return $this->productModel->getCategoryById($id); }
    public function updateCategory($id, $name, $image) { return $this->productModel->updateCategory($id, $name, $image); }

    // Products
    public function addProduct($cat, $brand, $title, $price, $desc, $image, $keywords) { return $this->productModel->addProduct($cat, $brand, $title, $price, $desc, $image, $keywords); }
    public function updateProduct($id, $cat, $brand, $title, $price, $desc, $image, $keywords) { return $this->productModel->updateProduct($id, $cat, $brand, $title, $price, $desc, $image, $keywords); }
    public function getProductById($id) { return $this->productModel->getProductById($id); }
    public function getFeaturedProducts($limit = 6) { return $this->productModel->getFeaturedProducts($limit); }
    public function getProductsByCategory($cat_id) { return $this->productModel->getProductsByCategory($cat_id); }
    public function getProductsByBrand($brand_id) { return $this->productModel->getProductsByBrand($brand_id); }
    public function searchProducts($query) { return $this->productModel->searchProducts($query); }

    public function deleteBrand($id) {
        return $this->productModel->deleteBrand($id);
    }

    public function deleteCategory($id) {
        return $this->productModel->deleteCategory($id);
    }


}


?>