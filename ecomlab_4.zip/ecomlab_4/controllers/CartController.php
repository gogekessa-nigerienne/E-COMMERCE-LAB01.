<?php
require_once __DIR__ . '/../classes/CartClass.php';

class CartController {
    private $cartModel;

    public function __construct() {
        $this->cartModel = new CartClass();
    }

    public function isInCart($pid, $ip) { return $this->cartModel->isInCart($pid, $ip); }
    public function addToCart($pid, $qty, $ip, $cid = null) { return $this->cartModel->addToCart($pid, $qty, $ip, $cid); }
    public function getCartItems($ip) { return $this->cartModel->getCartItems($ip); }
    public function getCartCount($ip) { return $this->cartModel->getCartCount($ip); }
    public function getCartTotal($ip) { return $this->cartModel->getCartTotal($ip); }
    public function removeFromCart($pid, $ip) { return $this->cartModel->removeFromCart($pid, $ip); }
    public function updateQty($pid, $qty, $ip) { return $this->cartModel->updateQty($pid, $qty, $ip); }
    public function getQty($pid, $ip) { return $this->cartModel->getQty($pid, $ip); }
}
?>