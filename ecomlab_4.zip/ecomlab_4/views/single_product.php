<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

if (!isset($_GET['pro_id']) || !is_numeric($_GET['pro_id'])) {
    redirect(BASE_URL . 'index.php');
}

$controller = new ProductController();
$product = $controller->getProductById((int) $_GET['pro_id']);

if (!$product) {
    redirect(BASE_URL . 'index.php');
}

require_once __DIR__ . '/layout/header.php';
?>

<h2><?php echo htmlspecialchars($product['product_title']); ?></h2>

<div style="display: flex; gap: 40px; margin-top: 20px; flex-wrap: wrap;">
    <!-- Left Side: Product Image -->
    <div style="flex: 1; min-width: 300px;">
        <img src="<?php echo BASE_URL . 'images/products/' . htmlspecialchars($product['product_image']); ?>"
            alt="<?php echo htmlspecialchars($product['product_title']); ?>"
            style="width: 100%; max-width: 400px; border-radius: 8px; border: 2px solid #111; object-fit: cover;">
    </div>

    <!-- Right Side: Product Details -->
    <div style="flex: 2; min-width: 300px;">
        <p style="font-size: 24px; font-weight: bold; color: #111; margin-bottom: 15px;">GH₵
            <?php echo number_format($product['product_price'], 2); ?></p>
        <p><strong>Category:</strong> <?php echo htmlspecialchars($product['cat_name']); ?></p>
        <p><strong>Brand:</strong> <?php echo htmlspecialchars($product['brand_name']); ?></p>
        <p><strong>Description:</strong></p>
        <p style="line-height: 1.6;"><?php echo nl2br(htmlspecialchars($product['product_desc'])); ?></p>
        <p style="margin-top: 15px;"><strong>Keywords:</strong>
            <?php echo htmlspecialchars($product['product_keywords']); ?></p>

        <br>
        <a href="<?php echo BASE_URL; ?>actions/add_to_cart.php?pid=<?php echo $product['product_id']; ?>" class="btn"
            ...>Add to Cart</a>
    </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>