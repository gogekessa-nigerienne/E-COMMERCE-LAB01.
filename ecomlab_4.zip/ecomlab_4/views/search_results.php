<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

$controller = new ProductController();
$query = $_GET['user_query'] ?? '';
$products = $controller->searchProducts($query);

require_once __DIR__ . '/layout/header.php';
?>

<h2>Search Results for "<?php echo htmlspecialchars($query); ?>"</h2>

<table>
    <thead>
        <tr>
            <th>Image</th>
            <th>Product Title</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($products) > 0): ?>
            <?php foreach ($products as $prod): ?>
                <tr>
                    <td>
                        <img src="<?php echo BASE_URL . 'images/products/' . htmlspecialchars($prod['product_image']); ?>" 
                             alt="<?php echo htmlspecialchars($prod['product_title']); ?>" 
                             style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px;"
                             onerror="this.src='<?php echo BASE_URL . 'images/products/default.jpg'; ?>'">
                    </td>
                    <td><?php echo htmlspecialchars($prod['product_title']); ?></td>
                    <td><strong>GH₵ <?php echo number_format($prod['product_price'], 2); ?></strong></td>
                    <td><a href="<?php echo BASE_URL; ?>views/single_product.php?pro_id=<?php echo $prod['product_id']; ?>" class="btn">View Details</a></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="4" style="text-align: center;">No products found matching your search.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/layout/footer.php'; ?>