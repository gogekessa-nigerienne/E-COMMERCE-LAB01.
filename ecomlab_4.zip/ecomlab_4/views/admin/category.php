<?php
require_once __DIR__ . '/../../core/core.php';
require_once __DIR__ . '/../../controllers/ProductController.php';
require_admin();

$controller = new ProductController();
$editCategory = null;
if (isset($_GET['edit_id'])) { $editCategory = $controller->getCategoryById($_GET['edit_id']); }

require_once __DIR__ . '/../layout/header.php';
?>

<h2><?php echo $editCategory ? 'Edit Category' : 'Manage Categories'; ?></h2>

<?php if (isset($_SESSION['success'])): ?>
    <div style="color: green; margin-bottom: 15px;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<form action="<?php echo BASE_URL; ?>actions/<?php echo $editCategory ? 'update_category_action.php' : 'add_category_action.php'; ?>" method="POST" enctype="multipart/form-data">
    <?php if ($editCategory): ?>
        <input type="hidden" name="cat_id" value="<?php echo $editCategory['cat_id']; ?>">
        <input type="hidden" name="current_image" value="<?php echo $editCategory['cat_image']; ?>">
    <?php endif; ?>
    <div>
        <label>Category Name:</label>
        <input type="text" name="cat_name" required value="<?php echo $editCategory ? htmlspecialchars($editCategory['cat_name']) : ''; ?>">
    </div>
    <div>
        <label>Category Image:</label>
        <input type="file" name="cat_image" accept="image/*">
        <?php if ($editCategory && !empty($editCategory['cat_image']) && $editCategory['cat_image'] != 'default.png'): ?>
            <p>Current: <img src="<?php echo BASE_URL . 'images/categories/' . $editCategory['cat_image']; ?>" width="80"></p>
        <?php endif; ?>
    </div>
    <button type="submit" class="btn"><?php echo $editCategory ? 'Update Category' : 'Add Category'; ?></button>
    <?php if ($editCategory): ?><a href="<?php echo BASE_URL; ?>views/admin/category.php" style="margin-left: 10px;">Cancel</a><?php endif; ?>
</form>

<hr>
<h3>All Categories</h3>
<table>
    <thead><tr><th>ID</th><th>Image</th><th>Category Name</th><th>Action</th></tr></thead>
    <tbody>
        <?php foreach ($controller->getAllCategories() as $cat): ?>
            <tr>
                <td><?php echo $cat['cat_id']; ?></td>
                <td><img src="<?php echo BASE_URL . 'images/categories/' . $cat['cat_image']; ?>" width="50" style="border-radius: 4px;"></td>
                <td><?php echo htmlspecialchars($cat['cat_name']); ?></td>
                <td><a href="<?php echo BASE_URL; ?>views/admin/category.php?edit_id=<?php echo $cat['cat_id']; ?>" class="btn">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>