<?php
require_once __DIR__ . '/../../core/core.php';
require_once __DIR__ . '/../../controllers/ProductController.php';
require_admin();

$controller = new ProductController();
$editBrand = null;
if (isset($_GET['edit_id'])) { $editBrand = $controller->getBrandById($_GET['edit_id']); }

require_once __DIR__ . '/../layout/header.php';
?>

<h2><?php echo $editBrand ? 'Edit Brand' : 'Manage Brands'; ?></h2>

<?php if (isset($_SESSION['success'])): ?>
    <div style="color: green; margin-bottom: 15px;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<form action="<?php echo BASE_URL; ?>actions/<?php echo $editBrand ? 'update_brand_action.php' : 'add_brand_action.php'; ?>" method="POST" enctype="multipart/form-data">
    <?php if ($editBrand): ?>
        <input type="hidden" name="brand_id" value="<?php echo $editBrand['brand_id']; ?>">
        <input type="hidden" name="current_image" value="<?php echo $editBrand['brand_image']; ?>">
    <?php endif; ?>
    <div>
        <label>Brand Name:</label>
        <input type="text" name="brand_name" required value="<?php echo $editBrand ? htmlspecialchars($editBrand['brand_name']) : ''; ?>">
    </div>
    <div>
        <label>Brand Image:</label>
        <input type="file" name="brand_image" accept="image/*">
        <?php if ($editBrand && !empty($editBrand['brand_image']) && $editBrand['brand_image'] != 'default.png'): ?>
            <p>Current: <img src="<?php echo BASE_URL . 'images/brands/' . $editBrand['brand_image']; ?>" width="80"></p>
        <?php endif; ?>
    </div>
    <button type="submit" class="btn"><?php echo $editBrand ? 'Update Brand' : 'Add Brand'; ?></button>
    <?php if ($editBrand): ?><a href="<?php echo BASE_URL; ?>views/admin/brand.php" style="margin-left: 10px;">Cancel</a><?php endif; ?>
</form>

<hr>
<h3>All Brands</h3>
<table>
    <thead><tr><th>ID</th><th>Image</th><th>Brand Name</th><th>Action</th></tr></thead>
    <tbody>
        <?php foreach ($controller->getAllBrands() as $brand): ?>
            <tr>
                <td><?php echo $brand['brand_id']; ?></td>
                <td><img src="<?php echo BASE_URL . 'images/brands/' . ($brand['brand_image'] ?? 'default.png'); ?>" width="50"></td>
                <td><?php echo htmlspecialchars($brand['brand_name']); ?></td>
                <td><a href="<?php echo BASE_URL; ?>views/admin/brand.php?edit_id=<?php echo $brand['brand_id']; ?>" class="btn">Edit</a></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>