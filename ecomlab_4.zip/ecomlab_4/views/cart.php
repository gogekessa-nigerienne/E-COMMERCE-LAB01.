<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CartController.php';

$ip = get_ip();
$controller = new CartController();
$items = $controller->getCartItems($ip);
$total = $controller->getCartTotal($ip);

require_once __DIR__ . '/layout/header.php';
?>

<h2>Your Shopping Cart</h2>

<?php if (isset($_SESSION['success'])): ?>
    <div style="color: green; margin-bottom: 15px;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div style="color: red; margin-bottom: 15px;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<?php if (count($items) > 0): ?>
    <form action="<?php echo BASE_URL; ?>actions/update_cart.php" method="POST">
        <table>
            <thead>
                <tr>
                    <th>Remove</th>
                    <th>Image</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><input type="checkbox" name="remove[]" value="<?php echo $item['product_id']; ?>"></td>
                        <td><img src="<?php echo BASE_URL . 'images/products/' . htmlspecialchars($item['product_image']); ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;"></td>
                        <td><?php echo htmlspecialchars($item['product_title']); ?></td>
                        <td>GH₵ <?php echo number_format($item['product_price'], 2); ?></td>
                        <td>
                            <input type="number" name="qty[<?php echo $item['product_id']; ?>]" value="<?php echo $item['qty']; ?>" min="1" style="width: 60px; padding: 5px;">
                        </td>
                        <td>GH₵ <?php echo number_format($item['product_price'] * $item['qty'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" style="text-align: right; font-weight: bold;">Total:</td>
                    <td style="font-weight: bold;">GH₵ <?php echo number_format($total, 2); ?></td>
                </tr>
            </tfoot>
        </table>
        
        <br>
        <button type="submit" name="action" value="update" class="btn">Update Cart</button>
        <button type="submit" name="action" value="remove" class="btn" style="background: #c0392b; border-color: #c0392b; color: white;">Remove Selected</button>
    </form>
    
    <br><br>
    <?php if (is_logged_in()): ?>
        <a href="<?php echo BASE_URL; ?>views/checkout.php" class="btn" style="padding: 12px 25px; font-size: 16px;">Proceed to Checkout</a>
    <?php else: ?>
        <p><a href="<?php echo BASE_URL; ?>views/login.php">Login</a> to proceed to checkout.</p>
    <?php endif; ?>
    
<?php else: ?>
    <p>Your cart is empty. <a href="<?php echo BASE_URL; ?>index.php">Continue shopping</a>.</p>
<?php endif; ?>

<?php require_once __DIR__ . '/layout/footer.php'; ?>