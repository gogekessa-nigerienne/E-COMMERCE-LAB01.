    </main>
</div>

<footer>
    <p>&copy; <?php echo date('Y'); ?> ecomlab_3. All rights reserved.</p>
</footer>

</body>
</html>