<div class="sidebar">
    <h3>ecomlab_3</h3>
    
    <ul>
        <li><a href="<?php echo BASE_URL; ?>index.php">Home</a></li>
        <li><a href="<?php echo BASE_URL; ?>views/categories.php">Categories</a></li>
        <li><a href="<?php echo BASE_URL; ?>views/brands.php">Brands</a></li>
        <li><a href="<?php echo BASE_URL; ?>views/cart.php">Cart</a></li>
    </ul>

    <div class="auth-links">
        <?php if (is_logged_in()): ?>
            <p style="margin-bottom: 10px;">Welcome,<br><strong><?php echo htmlspecialchars($_SESSION['customer_name']); ?></strong></p>
            <ul>
                <li><a href="<?php echo BASE_URL; ?>views/account/my_account.php">My Account</a></li>
                <?php if (is_admin()): ?>
                    <li style="margin-top: 15px;"><strong style="color: goldenrod;">Admin Panel</strong></li>
                    <li><a href="<?php echo BASE_URL; ?>views/admin/brand.php">Manage Brands</a></li>
                    <li><a href="<?php echo BASE_URL; ?>views/admin/category.php">Manage Categories</a></li>
                    <li><a href="<?php echo BASE_URL; ?>views/admin/product.php">Manage Products</a></li>
                <?php endif; ?>
                <li><a href="<?php echo BASE_URL; ?>logout.php">Logout</a></li>
            </ul>
        <?php else: ?>
            <ul>
                <li><a href="<?php echo BASE_URL; ?>views/register.php">Register</a></li>
                <li><a href="<?php echo BASE_URL; ?>views/login.php">Login</a></li>
            </ul>
        <?php endif; ?>
    </div>
</div>