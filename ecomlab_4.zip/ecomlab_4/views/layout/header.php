<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ecomlab_3</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/style.css">
</head>
<body>

<!-- TOP NAVBAR (full width, above everything) -->
<div class="top-navbar">
    <a href="<?php echo BASE_URL; ?>index.php" class="logo">EcomWeb</a>
    
    <div class="nav-right">
        <!-- Search Form -->
        <form action="<?php echo BASE_URL; ?>views/search_results.php" method="GET" class="search-form">
            <input type="text" name="user_query" placeholder="Search products...">
            <button type="submit">Search</button>
        </form>
        
        <!-- Nav Links -->
        <a href="<?php echo BASE_URL; ?>views/brands.php">See Brands</a>
        <a href="<?php echo BASE_URL; ?>views/categories.php">See Categories</a>
        
        <?php 
            require_once __DIR__ . '/../../controllers/CartController.php';
            $cartHeaderController = new CartController();
            $cartCount = $cartHeaderController->getCartCount(get_ip());
        ?>
        <a href="<?php echo BASE_URL; ?>views/cart.php" class="cart-link">🛒 Cart (<?php echo $cartCount; ?>)</a>
        
        <?php if (is_logged_in()): ?>
            <a href="<?php echo BASE_URL; ?>views/account/my_account.php">My Account</a>
            <a href="<?php echo BASE_URL; ?>logout.php">Logout</a>
        <?php else: ?>
            <a href="<?php echo BASE_URL; ?>views/login.php">Login</a>
            <a href="<?php echo BASE_URL; ?>views/register.php">Sign Up</a>
        <?php endif; ?>
    </div>
</div>

<!-- WRAPPER (sidebar + content side by side) -->
<div class="wrapper">
    <?php require_once __DIR__ . '/sidebar.php'; ?>
    
    <main class="content">