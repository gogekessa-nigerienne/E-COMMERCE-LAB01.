<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

$controller = new ProductController();
$products = [];

if (isset($_GET['cat'])) {
    $products = $controller->getProductsByCategory((int)$_GET['cat']);
} elseif (isset($_GET['brand'])) {
    $products = $controller->getProductsByBrand((int)$_GET['brand']);
} else {
    $products = $controller->getFeaturedProducts(6);
}

require_once __DIR__ . '/layout/header.php';
?>

<!-- Yellow Welcome Box -->
<div class="hero-box">
    <h1>Welcome to e-commerce web application</h1>
    <p>Let's get started.</p>
</div>

<h2>Featured Products</h2>

<table>
    <thead>
        <tr>
            <th>Image</th>
            <th>Product Title</th>
            <th>Category</th>
            <th>Brand</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($products) > 0): ?>
            <?php foreach ($products as $prod): ?>
                <tr>
                    <td>
                        <!-- Product Image Display with Fallback -->
                        <img src="<?php echo BASE_URL . 'images/products/' . htmlspecialchars($prod['product_image']); ?>" 
                             alt="<?php echo htmlspecialchars($prod['product_title']); ?>" 
                             style="width: 80px; height: 80px; object-fit: cover; border-radius: 4px;"
                             onerror="this.src='<?php echo BASE_URL . 'images/products/default.jpg'; ?>'">
                    </td>
                    <td><?php echo htmlspecialchars($prod['product_title']); ?></td>
                    <td><?php echo htmlspecialchars($prod['cat_name']); ?></td>
                    <td><?php echo htmlspecialchars($prod['brand_name']); ?></td>
                    <td><strong>GH₵ <?php echo number_format($prod['product_price'], 2); ?></strong></td>
                    <td>
                        <a href="<?php echo BASE_URL; ?>views/single_product.php?pro_id=<?php echo $prod['product_id']; ?>" class="btn">View Details</a>
                        <td>
                        <a href="<?php echo BASE_URL; ?>views/single_product.php?pro_id=<?php echo $prod['product_id']; ?>" class="btn" style="margin-bottom: 5px; display: block;">View Details</a>
                        <a href="<?php echo BASE_URL; ?>actions/add_to_cart.php?pid=<?php echo $prod['product_id']; ?>" class="btn" style="background: #111; color: goldenrod; display: block;">Add to Cart</a>
                        </td>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="6" style="text-align: center;">No products found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/layout/footer.php'; ?>