<?php
require_once __DIR__ . '/../core/db_class.php';

class CartClass extends Database {

    // Check if a product is already in the cart for this IP
    public function isInCart($pid, $ip) {
        $sql = "SELECT * FROM cart WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $pid, $ip);
        $stmt->execute();
        return $stmt->get_result()->num_rows > 0;
    }

    // Add product to cart
    public function addToCart($pid, $qty, $ip, $cid = null) {
        $sql = "INSERT INTO cart (p_id, ip_add, c_id, qty) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        // If $cid is null, we need a variable reference for bind_param
        $null = null;
        $cidToBind = ($cid === null) ? $null : $cid;
        $stmt->bind_param("isii", $pid, $ip, $cidToBind, $qty);
        return $stmt->execute();
    }

    // Get all cart items with product details
    public function getCartItems($ip) {
        $sql = "SELECT c.qty, p.* FROM cart c 
                JOIN products p ON c.p_id = p.product_id 
                WHERE c.ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $ip);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // Get total quantity of items in cart
    public function getCartCount($ip) {
        $sql = "SELECT SUM(qty) as count FROM cart WHERE ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $ip);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['count'] ?? 0;
    }

    // Get total price of cart
    public function getCartTotal($ip) {
        $sql = "SELECT SUM(c.qty * p.product_price) as total FROM cart c 
                JOIN products p ON c.p_id = p.product_id 
                WHERE c.ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $ip);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['total'] ?? 0;
    }

    // Remove a product from cart
    public function removeFromCart($pid, $ip) {
        $sql = "DELETE FROM cart WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $pid, $ip);
        return $stmt->execute();
    }

    // Update quantity of a product in cart
    public function updateQty($pid, $qty, $ip) {
        if ($qty < 1) { $qty = 1; }
        $sql = "UPDATE cart SET qty = ? WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iis", $qty, $pid, $ip);
        return $stmt->execute();
    }

    // Get the current quantity of a specific product in cart
    public function getQty($pid, $ip) {
        $sql = "SELECT qty FROM cart WHERE p_id = ? AND ip_add = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $pid, $ip);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['qty'] ?? 0;
    }
}
?>