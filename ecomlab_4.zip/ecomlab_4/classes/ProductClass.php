<?php
require_once __DIR__ . '/../core/db_class.php';

class ProductClass extends Database {

    // ===== BRANDS =====
    public function addBrand($name, $image) {
        $sql = "INSERT INTO brands (brand_name, brand_image) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $name, $image);
        return $stmt->execute();
    }
    public function getAllBrands() {
        $sql = "SELECT * FROM brands ORDER BY brand_name ASC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function getBrandById($id) {
        $sql = "SELECT * FROM brands WHERE brand_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    public function updateBrand($id, $name, $image) {
        $sql = "UPDATE brands SET brand_name = ?, brand_image = ? WHERE brand_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssi", $name, $image, $id);
        return $stmt->execute();
    }

    // ===== CATEGORIES =====
    public function addCategory($name, $image) {
        $sql = "INSERT INTO categories (cat_name, cat_image) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $name, $image);
        return $stmt->execute();
    }
    public function getAllCategories() {
        $sql = "SELECT * FROM categories ORDER BY cat_name ASC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function getCategoryById($id) {
        $sql = "SELECT * FROM categories WHERE cat_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    public function updateCategory($id, $name, $image) {
        $sql = "UPDATE categories SET cat_name = ?, cat_image = ? WHERE cat_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssi", $name, $image, $id);
        return $stmt->execute();
    }

    // ===== PRODUCTS (keep your existing product methods below) =====
    public function addProduct($cat, $brand, $title, $price, $desc, $image, $keywords) {
        $sql = "INSERT INTO products (product_cat, product_brand, product_title, product_price, product_desc, product_image, product_keywords) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iisssss", $cat, $brand, $title, $price, $desc, $image, $keywords);
        return $stmt->execute();
    }
    public function updateProduct($id, $cat, $brand, $title, $price, $desc, $image, $keywords) {
        $sql = "UPDATE products SET product_cat=?, product_brand=?, product_title=?, product_price=?, product_desc=?, product_image=?, product_keywords=? WHERE product_id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iisssssi", $cat, $brand, $title, $price, $desc, $image, $keywords, $id);
        return $stmt->execute();
    }
    public function getProductById($id) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p JOIN categories c ON p.product_cat = c.cat_id JOIN brands b ON p.product_brand = b.brand_id WHERE p.product_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    public function getFeaturedProducts($limit = 6) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p JOIN categories c ON p.product_cat = c.cat_id JOIN brands b ON p.product_brand = b.brand_id ORDER BY RAND() LIMIT ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function getProductsByCategory($cat_id) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p JOIN categories c ON p.product_cat = c.cat_id JOIN brands b ON p.product_brand = b.brand_id WHERE p.product_cat = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $cat_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function getProductsByBrand($brand_id) {
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p JOIN categories c ON p.product_cat = c.cat_id JOIN brands b ON p.product_brand = b.brand_id WHERE p.product_brand = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $brand_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function searchProducts($query) {
        $search = "%" . $query . "%";
        $sql = "SELECT p.*, c.cat_name, b.brand_name FROM products p JOIN categories c ON p.product_cat = c.cat_id JOIN brands b ON p.product_brand = b.brand_id WHERE p.product_title LIKE ? OR p.product_keywords LIKE ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $search, $search);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
?>