<?php
// This file stores the database connection settings in one place.
// Keeping credentials here (instead of inside db_class.php) means
// you only have to update them in one spot if the database changes.

// define() creates a global constant - a named value that cannot
// be changed anywhere else in the app once it is set here.


define('DB_HOST', 'localhost');
define('DB_USER', 'mariam.kessa');
define('DB_PASS', '30682027');
define('DB_NAME', 'ecommerce_2026A_mariam_kessa');
?>