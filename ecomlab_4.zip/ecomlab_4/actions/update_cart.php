<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CartController.php';

$ip = get_ip();
$controller = new CartController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update' && isset($_POST['qty'])) {
        foreach ($_POST['qty'] as $pid => $qty) {
            $controller->updateQty((int)$pid, (int)$qty, $ip);
        }
        $_SESSION['success'] = 'Cart updated.';
    } elseif ($action === 'remove' && isset($_POST['remove'])) {
        foreach ($_POST['remove'] as $pid) {
            $controller->removeFromCart((int)$pid, $ip);
        }
        $_SESSION['success'] = 'Item(s) removed from cart.';
    }
}

redirect(BASE_URL . 'views/cart.php');
?>