<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/CartController.php';

$ip = get_ip();
$pid = filter_var($_GET['pid'] ?? 0, FILTER_VALIDATE_INT);

if (!$pid) {
    redirect(BASE_URL . 'index.php');
}

$controller = new CartController();

if ($controller->isInCart($pid, $ip)) {
    $_SESSION['error'] = 'This product is already in your cart.';
} else {
    $controller->addToCart($pid, 1, $ip, $_SESSION['customer_id'] ?? null);
    $_SESSION['success'] = 'Product added to cart successfully.';
}

// Redirect back to where the user came from
$referer = $_SERVER['HTTP_REFERER'] ?? BASE_URL . 'index.php';
redirect($referer);
?>