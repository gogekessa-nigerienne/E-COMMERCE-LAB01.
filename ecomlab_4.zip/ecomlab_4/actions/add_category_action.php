<?php
require_once __DIR__ . '/../core/core.php';
require_once __DIR__ . '/../controllers/ProductController.php';

require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect(BASE_URL . 'views/admin/category.php'); }

$name = trim(strip_tags($_POST['cat_name'] ?? ''));
$image = 'default.png';

if (isset($_FILES['cat_image']) && $_FILES['cat_image']['error'] === UPLOAD_ERR_OK) {
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (in_array($_FILES['cat_image']['type'], $allowed)) {
        $filename = uniqid() . '.' . pathinfo($_FILES['cat_image']['name'], PATHINFO_EXTENSION);
        $upload_dir = __DIR__ . '/../images/categories/';
        if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }
        if (move_uploaded_file($_FILES['cat_image']['tmp_name'], $upload_dir . $filename)) {
            $image = $filename;
        }
    }
}

$controller = new ProductController();
if ($controller->addCategory($name, $image)) {
    $_SESSION['success'] = 'Category added successfully.';
} else {
    $_SESSION['error'] = 'Failed to add category.';
}
redirect(BASE_URL . 'views/admin/category.php');
?>