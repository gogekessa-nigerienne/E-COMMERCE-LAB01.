<?php
require "db.php";
$id = intval($_GET["id"] ?? 0);
if ($id > 0) {
$stmt = $conn->prepare("DELETE FROM tasks WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();
}

?>

<?php 
$conn->close();
header("Location: index.php");
Exit;
?>