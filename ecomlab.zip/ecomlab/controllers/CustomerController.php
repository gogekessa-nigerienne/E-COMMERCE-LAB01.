<?php
require_once '../classes/CustomerClass.php';
require_once '../core/db_class.php';


class CustomerController
{
    private $model;

    public function __construct()
    {
        $this->model = new CustomerClass();
    }

    public function register($data)
    {
        if ($this->model->emailExists($data['email'])) {
            return ['success' => false, 'error' => 'Email already registered'];
        }
        $ok = $this->model->addCustomer(
            $data['name'],
            $data['email'],
            $data['pass'],
            $data['country'],
            $data['city'],
            $data['contact']
        );
        return $ok ? ['success' => true] : ['success' => false, 'error' => 'Registration failed'];
    }

    public function login($email, $pass)
    {
        $user = $this->model->login($email, $pass);
        if ($user) {
            return $user;
        }
        return ['error' => 'Invalid email or password'];
    }







}
?>