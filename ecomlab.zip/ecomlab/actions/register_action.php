<?php
require_once '../core/core.php';
require_once '../controllers/CustomerController.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim(strip_tags($_POST['name']));
    $email   = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $pass    = $_POST['pass'];
    $country = trim($_POST['country']);
    $city    = trim($_POST['city']);
    $contact = trim($_POST['contact']);

    if (!$email) {
        $_SESSION['error'] = "Invalid email address.";
        redirect('../views/register.php');
    }

    $controller = new CustomerController();
    $result = $controller->register([
        'name' => $name,
        'email' => $email,
        'pass' => $pass,
        'country' => $country,
        'city' => $city,
        'contact' => $contact
    ]);

    if ($result['success']) {
        $_SESSION['customer_id'] = $this->conn->insert_id;
        $_SESSION['user_role'] = 2; // default customer
        redirect('../views/account/my_account.php');
    } else {
        $_SESSION['error'] = $result['error'];
        redirect('../views/register.php');
    }
}
?>

