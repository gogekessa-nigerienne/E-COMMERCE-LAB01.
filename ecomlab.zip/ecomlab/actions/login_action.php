<?php
require_once '../core/core.php';
require_once '../controllers/CustomerController.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $pass  = $_POST['password'];

    if (!$email || strlen($pass) < 8) {
        $_SESSION['error'] = "Invalid email or password.";
        redirect('../views/login.php');
    }

    $controller = new CustomerController();
    $user = $controller->login($email, $pass);

    if (isset($user['customer_id'])) {
        $_SESSION['customer_id']   = $user['customer_id'];
        $_SESSION['customer_name'] = $user['customer_name'];
        $_SESSION['customer_email']= $user['customer_email'];
        $_SESSION['user_role']     = $user['user_role'];
        redirect('../index.php');
    } else {
        $_SESSION['error'] = $user['error'];
        redirect('../views/login.php');
    }
}
?>
