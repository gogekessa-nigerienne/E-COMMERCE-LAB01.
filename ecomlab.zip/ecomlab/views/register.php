<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container">
    <h1>Register</h1>

    <?php if (isset($_SESSION['error'])): ?>
        <p class="error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>

    <form action="../actions/register_action.php" method="POST">
        <label>Full Name</label>
        <input type="text" name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="pass" minlength="8" required>

        <label>Country</label>
        <input type="text" name="country" required>

        <label>City</label>
        <input type="text" name="city" required>

        <label>Contact Number</label>
        <input type="text" name="contact" required>

        <button type="submit">Register</button>
    </form>

    <div class="form-footer">
        Already have an account? <a href="login.php">Login here</a>
    </div>
</div>
</body>
</html>

