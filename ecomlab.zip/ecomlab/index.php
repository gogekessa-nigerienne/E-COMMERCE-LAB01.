<!--
	This is the homepage / entry point of the app.
	It links out to the two customer pages under the view/ folder.
-->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ecom LAB</title>
</head>
<body>
	<h1>This is ecom lab started</h1>
	<nav>
		<a href="views/register.php">Register Customer</a> |
		<a href="views/customers.php">View All Customers</a>
	</nav>
</body>
</html>
